ChronoChat - A Serverless Chat Application in NDN
=================================================

ChatRoom
--------

The sync prefix of a chatroom is defined as: ``/ndn/broadcast/ChronoChat/[chatroom]``.


..
   Invitation
   ----------

   Every application listen to a invitation prefix: ``/<routing_hint>/<user_prefix>/CHRONOCHAT-INVITATION``
